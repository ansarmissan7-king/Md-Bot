module.exports = {
    giphyApiKey: process.env.GIPHY_API_KEY || 'dc6zaTOxFJmzC',
    ownerNumber: process.env.OWNER_NUMBER || '923299762939',
    botName: '𝗔𝗡𝗦𝗔𝗥 𝗞𝗜𝗡𝗚 MD',
    ownerName: '𝗔𝗡𝗦𝗔𝗥 𝗞𝗜𝗡𝗚'
};
